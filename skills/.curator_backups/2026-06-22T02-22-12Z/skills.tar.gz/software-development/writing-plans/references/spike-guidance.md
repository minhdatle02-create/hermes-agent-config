# Spike Guidance (merged from plan / spike)

**When to spike instead of planning a full feature**

- A dependency is unfinished and TDD would force you to write stubs and overbuild.
- You want to validate an assumption cheaply before committing to a plan.
- Spike = temporary experiment branch, not a merge target.

## Rails rebuild workflow (when to use)
Phase 1 Backfill
  - Reconstruct context from root README / CONTRIBUTING / CHANGELOG.
  - Recreate directory structures, routing, views, and provide surgical patches.
Phase 2 Work
  - Use swift surgical patches; avoid manual reverts of validations.
  - Use existing tests as constraints, not guarantees.
Phase 3 Resume & cleanup
  - Stop on failure or repeated blockage; rebuild workspace, re-read resume instructions, then resume.
  - Validate with tests before declaring success; CI green = done.

## Code review guidance (agent)
- Review patches, not raw source; locate reads/writes with ripgrep.
- Ask "would this patch introduce a bug?" — do not make suggestions.

## Plan Recovery
If a plan gets stale mid-run (succeeded-but-unapplied, needs-revision, or already-complete), abort early and ask how to proceed.

## Planning Mode
- Bypass Plan-Builder; do not write a full plan when invoked in plan mode.
- Do NOT use TodoWrite / TodoRead in this session.
- Do NOT re-run the research step; the builder already studied the problem.
- Do NOT use delegate_task.