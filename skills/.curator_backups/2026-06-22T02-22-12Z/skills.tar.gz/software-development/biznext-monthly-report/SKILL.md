---
name: biznext-monthly-report
description: >
  Build a monthly Excel report for BizNext from CRM Public API Leads.
  Triggers: monthly report, BizNext report, CRM leads report.
  Covers: total leads, contracts, follow-ups, revenue by service, sale performance.
  Note: this skill is for fixed calendar-month reports only.
  For weekly/ad-hoc windows, use biznext-reporting instead.
---

# BizNext Monthly Report

Generate an Excel `.xlsx` monthly report for BizNext from the CRM Public API Leads endpoint.

- `scripts/report.py` → monthly Excel workbook
- `scripts/daily_digest.py` → daily Telegram summary

## Usage

### Monthly Excel report
```bash
python scripts/report.py
```
Then send the generated Excel file to Telegram via `send_message`/`cronjob` `deliver`.

### Daily Telegram summary (requires Hermes Telegram channel setup)

```bash
python scripts/daily_digest.py
```
Output is plain text and can be delivered automatically by a `cronjob` to Telegram origin.

## Configuration

Edit the top of `scripts/report.py` before running:
- `API_KEY`: CRM API key (read-only)
- `REPORT_YEAR`: integer year
- `REPORT_MONTH`: 1-12 month
- `API_URL`: environment URL

## Output Sheets

1. `Tong_quan` - Total leads, contracts, revenue, pending follow-ups
2. `Lead_theo_sale` - Lead count, contracts, follow-ups, revenue per sale
3. `Co_hoi_trang_thai` - Opportunity counts by status
4. `Doanh_thu_dich_vu` - Revenue and contract counts by service
5. `Follow_list` - Filtered follow-up leads

## Dependencies

```bash
python -m pip install openpyxl
```

## Source

Data comes from: Public API Leads (Read-only)
Endpoint: `GET /api/public/leads`
Auth: `X-API-KEY`
