---
name: biznext-reporting
description: >
  Build on-demand or scheduled CRM-backed reporting for BizNext.
  Use when fetching CRM lead data, generating summary reports,
  producing Excel aggregation outputs, or packaging recurring
  weekly business reviews for sales operations.
toolsets:
  - terminal
  - file
  - web
---

# BizNext Reporting

Build and ship reports from the BizNext CRM into a workbook or other format.
This skill is class-level: it covers any BizNext sales/lead reporting need.

## Step 1: Confirm the report contract

Before scripting, confirm with the user:
- output format (default: Excel)
- schedule model (default: run on demand)
- distribution channel (Telegram when chat is configured)
- KPIs to compute from CRM data
- time window: by default use current month unless the user specifies a different week/month

## Step 2: Authenticate and probe the CRM

Use the Public API Leads endpoint:
- Production: `https://leadapi.biznext.vn/api/public/leads`
- Auth header: `X-API-KEY`
- Response: JSON array
- Rate limit applies; therefore probe with a small fetch first, not multiple parallel calls.
- Store the key in Hermes config: `hermes config set BIZNEXT_API_KEY <key>`. It is written to `~/.hermes/.env` and
  kept out of chat. Do NOT ask the user to re-send the key in later sessions.
- Windows env caveat: running a script via `python script.py` does not automatically inherit the Hermes-loaded env
  unless the Hermes runtime loads it. If you get `401`, verify the header value is set inside the script before
  relying on `os.environ`.

### New-opportunity definition (anti-batch)

`createdAt` contains clustered batch dates (many records share one date), so filtering by that field alone
underestimates "new in window". Prefer:
1. `contractDate == window_date` AND status in `Contract`/`Closed` for "new contracts".
2. "New leads" should be derived from an ID threshold / max-seen-id approach, or by whichever field proved
   stable in the most recent sync (see `references/biznext-crm-api.md`).

### Verification

After auth succeeds, record `max id` from the dataset so future "newness" checks can use an ID floor.

## Pitfalls

- NEVER reuse partial output if the CRM call fails. If production returns 400/401/429/500, stop and report the exact status and body, do not synthesize report data.
- Do not synthesize CRM numbers when auth fails. 401 = broken header or expired key; 400/429 = request issue. Stop and surface the exact reason.
- Avoid creating base64/encoded blobs of the workbook in chat; send or return the file path instead.
- Do not guess missing source files. If the user asks for source material that is not found, ask for the exact path.
- Telegram delivery: emit bullet lists with `key: value` lines, not tables. Telegram auto-rewrites pipe tables into row-group bullets, which loses structure.

## Step 3: Generate output

Default output locations:
- `~/AppData/Local/hermes/cron/output/BizNext_Weekly_<YYYYMMDD>.xlsx`

Default workbook sheets:
1. Summary
2. Sales breakdown
3. Opportunity status
4. Revenue by service
5. Follow-up list

## Step 4: Delivery

Preferred delivery is Telegram when `TELEGRAM_HOME_CHANNEL` is configured.
If Telegram is not configured, return the file path and instruct the user to run:
`hermes config set TELEGRAM_HOME_CHANNEL <chat_id>`

## Session references

See `references/biznext-crm-api.md` for endpoint details and filtering constraints.
See `references/biznext-new-opportunity-rules.md` for anti-batch rules Window deduction and daily report logic.
