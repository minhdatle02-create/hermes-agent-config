import urllib.request, json, os, ssl
from datetime import datetime, date, timezone, timedelta

API_URL = "https://leadapi.biznext.vn/api/public/leads"
API_KEY = "ffVdNG9cc5H9LoSJvrG1BACJVlpEuTw8"

# Use Vietnam timezone (UTC+7) for day filtering to match CRM dates accurately
VN_TZ = timezone(timedelta(hours=7))

def now_vn():
    return datetime.now(VN_TZ)

def today_vn():
    return now_vn().date()

def fetch_leads():
    req = urllib.request.Request(
        API_URL,
        headers={"X-API-KEY": API_KEY, "Accept": "application/json"},
        method="GET",
    )
    ctx = ssl.create_default_context() if API_URL.startswith("https") else None
    with urllib.request.urlopen(req, timeout=30, context=ctx) as resp:
        raw = resp.read().decode("utf-8", errors="replace")
    return json.loads(raw)

def parse_date(value):
    if not value:
        return None
    value = str(value).strip()
    if not value:
        return None
    # Accept YYYY-MM-DD or YYYY-MM-DDTHH:MM...
    for fmt in ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M:%S.%f", "%Y-%m-%dT%H:%M:%S.%fZ"):
        try:
            return datetime.strptime(value[:len(fmt.replace('%Y','0000').replace('%m','00').replace('%d','00').replace('%H','00').replace('%M','00').replace('%S','00').replace('%f','000000').replace('T','').replace('-','').replace(':','').replace('.','').replace('Z',''))], fmt).date()
        except Exception:
            pass
    return None

def fmt_vnd(value):
    try:
        return f"{float(value):,.0f} VND"
    except Exception:
        return "0 VND"

def build_report():
    leads = fetch_leads()
    today = today_vn()
    day_str = today.strftime("%d/%m/%Y")

    new_leads = []
    new_contracts = []
    for item in leads:
        created = parse_date(item.get("createdAt"))
        contract = parse_date(item.get("contractDate"))
        status = (item.get("status") or "").strip().lower()
        if created == today:
            new_leads.append(item)
        if contract == today and status in ("contract", "closed"):
            new_contracts.append(item)

    # Dedupe by id to avoid double-counting
    seen = set()
    deduped_leads = []
    for x in new_leads:
        if x.get("id") not in seen:
            seen.add(x.get("id"))
            deduped_leads.append(x)
    seen = set()
    deduped_contracts = []
    for x in new_contracts:
        if x.get("id") not in seen:
            seen.add(x.get("id"))
            deduped_contracts.append(x)

    lines = []
    lines.append(f"Báo cáo BizNext CRM ngày {day_str}")
    lines.append("")

    lines.append(f"• Cơ hội mới: {len(deduped_leads)}")
    if deduped_leads:
        for idx, x in enumerate(deduped_leads[:30], 1):
            sale = x.get("sale") or "-"
            service = x.get("service") or "-"
            revenue = fmt_vnd(x.get("revenue") or 0)
            lines.append(f"  {idx}. {x.get('name','-')} | Sale: {sale} | DV: {service} | Dự kiến: {revenue}")
        if len(deduped_leads) > 30:
            lines.append(f"  ... và {len(deduped_leads)-30} cơ hội khác")
    lines.append("")

    lines.append(f"• Hợp đồng mới: {len(deduped_contracts)}")
    if deduped_contracts:
        for idx, x in enumerate(deduped_contracts[:30], 1):
            sale = x.get("sale") or "-"
            service = x.get("service") or "-"
            revenue = fmt_vnd(x.get("revenue") or 0)
            lines.append(f"  {idx}. {x.get('name','-')} | Sale: {sale} | DV: {service} | Giá trị: {revenue}")
        if len(deduped_contracts) > 30:
            lines.append(f"  ... và {len(deduped_contracts)-30} hợp đồng khác")
    lines.append("")

    lines.append(f"• Tổng hợp nhanh:")
    total_revenue_leads = sum(float(x.get("revenue") or 0) for x in deduped_leads)
    total_revenue_contracts = sum(float(x.get("revenue") or 0) for x in deduped_contracts)
    lines.append(f"  - Doanh thu dự kiến từ cơ hội mới: {fmt_vnd(total_revenue_leads)}")
    lines.append(f"  - Doanh thu thực tế từ hợp đồng mới: {fmt_vnd(total_revenue_contracts)}")

    return today, deduped_leads, deduped_contracts, "\n".join(lines)

if __name__ == "__main__":
    today, leads, contracts, report = build_report()
    print(report)
